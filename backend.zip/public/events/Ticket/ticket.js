
document.addEventListener("DOMContentLoaded", () => {
    const ticketPrice = 5.77; // base ticket price
    let feePrice = 2.23; // base additional fee
    let quantity = 1;
    let promoDiscount = 0; // No discount by default

    const quantityInput = document.getElementById('quantityInput');
    const decrementBtn = document.getElementById('decrementBtn');
    const incrementBtn = document.getElementById('incrementBtn');
    const applyPromoButton = document.getElementById('applyPromoButton');
    const promoCodeInput = document.getElementById('promoCodeInput');
    const checkoutButton = document.getElementById('checkoutButton');
    const subtotalPrice = document.getElementById('subtotalPrice');
    const feePriceElement = document.getElementById('feePrice');
    const totalPrice = document.getElementById('totalPrice');
    const itemPrice = document.getElementById('itemPrice');
    
    // Function to calculate the fee dynamically, multiplying by quantity
    function calculateFee(quantity) {
        return 2.23 * quantity;  // Fee multiplied by quantity
    }

    // Update the price details
    function updatePrice() {
        const subtotal = ticketPrice * quantity;
        feePrice = calculateFee(quantity);  // Calculate the new fee based on quantity
        const total = subtotal + feePrice - promoDiscount;
        
        // Update the DOM with new values
        subtotalPrice.textContent = `$${subtotal.toFixed(2)}`;
        feePriceElement.textContent = `$${feePrice.toFixed(2)}`;
        totalPrice.textContent = `$${total.toFixed(2)}`;
        itemPrice.textContent = `$${ticketPrice.toFixed(2)} x ${quantity}`;
    }

    // Increment quantity
    incrementBtn.addEventListener('click', () => {
        quantity++;
        quantityInput.value = quantity;
        updatePrice();
    });

    // Decrement quantity
    decrementBtn.addEventListener('click', () => {
        if (quantity > 1) {
            quantity--;
            quantityInput.value = quantity;
            updatePrice();
        }
    });

    // Update quantity from input
    quantityInput.addEventListener('change', () => {
        quantity = parseInt(quantityInput.value) || 1;
        updatePrice();
    });

    // Apply promo code
    applyPromoButton.addEventListener('click', () => {
        const promoCode = promoCodeInput.value.trim().toUpperCase();
        if (promoCode === 'DISCOUNT10') {
            promoDiscount = 1.00; // 10% discount
            alert('Promo code applied!');
        } else {
            promoDiscount = 0;
            alert('Invalid promo code');
        }
        updatePrice();
    });

    // Checkout
    checkoutButton.addEventListener('click', () => {
        // You can implement actual checkout logic here
        alert('Proceeding to checkout...');
    });

    // Initial price update
    updatePrice();
});
